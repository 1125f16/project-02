// Import the interface to Tessel hardware
var tessel = require('tessel');
var os = require('os');
var fs = require('fs');
var url = require('url');
var http = require('http');
var mysql = require("mysql");
var express    = require("express");
var av = require('tessel-av');

var app = express();

var port = 8083;

var ip_address = require('os').networkInterfaces().wlan0[0].address;

//var ip_address = '10';

var camera = new av.Camera({
  width: 320,
  height: 240,
});

var server = http.createServer((request, response) => {

  response.writeHead(200, { "Content-Type": "image/jpg" });
 
  var urlParts = url.parse(request.url, true);

    // Create a regular expression to match requests to toggle LEDs
    var ledRegex = /captureImage/;
    var postImage = /postImage/;

    if (urlParts.pathname.match(ledRegex)) {

       //camera.capture().pipe(response);

       var capture = camera.capture();

       capture.pipe(response);

       capture.on('data',function(data){

        console.log("Image Captured :" + data);

        processImage(data);

  });

    }  else {

     console.log(" Display index.html ");

    response.writeHead(200, {"Content-Type": "text/html"});

    // Use fs to read in index.html
    fs.readFile(__dirname + '/index.html', function (err, content) {
      // If there was an error, throw to stop code execution
      if (err) {
        throw err;
      }
      // Serve the content of index.html read in by fs.readFile
      response.end(content);
    });

    }
 
}).listen(port, () => console.log(`http://${ip_address}:${port}`));


function processImage (image_data) {
      

      var detected_face_id = '';
    // Call Microsoft Face Match API
  
                parseURL = require('url');
                parsedURL = parseURL.parse("https://api.projectoxford.ai/face/v1.0/detect");
                console.log(parsedURL.host);
                var options = {

                        host: parsedURL.host,

                        path: "/vision/v1.0/analyze?visualFeatures=Description,Tags",

                        headers: {
                                'Content-Type':'application/octet-stream',
                                'Content-Length':image_data.length,
                                'Ocp-Apim-Subscription-Key':'24bbe36547504ae6a296eb2125f1c551'
                        },



                        method:'POST', 
                        
                        params: {
            // Request parameters
                      "returnFaceId": "true",
                      "returnFaceLandmarks": "false",
                      "returnFaceAttributes": "{string}",
                       },

                       data: image_data 
                     };


                var callback = function(response){
                        var str ='';
                        response.on('data', function(chunk){
                                str+= chunk;
                        });

                        response.on('end', function(){

                                var obj = JSON.parse(str);

                                if (obj.faceId != null) {

                              // Returning Customer     
                                
                                detected_face_id = obj.faceId;

                                analyse_emotions(detected_face_id);

                              } else {

                              // New Coustomer 


                              // 1. Analyze the emotions

                              //2. Create customer entry in our database 

                              //3. Create entry in Face-List API 

                              //4. Return


                              }

                                console.log("I think the caption of this object should be " + obj.description.captions[0].text+". I am "+obj.description.captions[0].confidence+"sure.");

                        });

                };

                var post_req = http.request(options, callback);

                post_req.write(data);

                post_req.end();

          ////////////////////


    }

//// DATABASE MANAGEMENT SYSTEM //////

// First you need to create a connection to the db
var con = mysql.createConnection({
  host: 'matchnow.cyrm1j58aafh.us-west-2.rds.amazonaws.com',
  user: 'chahatjain08',
  password: "Mastermind#08#1989",
  database: 'customer_tb',
 // serverId : '2'
});

con.connect(function(err){
  if(err){
    console.log('Error connecting to Db: ' + err);
  } else {
  console.log('Connection established');
}
});


// QUERY //

 /*con.query('SELECT * FROM employees',function(err,rows){
  if(err) throw err;

  console.log('Data received from Db:\n');
  console.log(rows);
});

// INSERTING //

var employee = { name: 'Winnie', location: 'Australia' };
con.query('INSERT INTO employees SET ?', employee, function(err,res){
  if(err) throw err;

  console.log('Last insert ID:', res.insertId);
});

// UPDATING //

con.query(
  'UPDATE employees SET location = ? Where ID = ?',
  ["South Africa", 5],
  function (err, result) {
    if (err) throw err;

    console.log('Changed ' + result.changedRows + ' rows');
  }
);

// DESTROYING //

con.query(
  'DELETE FROM employees WHERE id = ?',
  [5],
  function (err, result) {
    if (err) throw err;

    console.log('Deleted ' + result.affectedRows + ' rows');
  }
); 


con.end(function(err) {
  // The connection is terminated gracefully
  // Ensures all previously enqueued queries are still
  // before sending a COM_QUIT packet to the MySQL server.
});*/

/*else if (urlParts.pathname.match(postImage)) {
       
      if (request.method == 'POST') {

        var imageString = '';

        req.on('data', function (data) {
            imageString += data;
        });

        req.on('end', function () {
            console.log(JSON.parse(imageString));
        });

        processImage(imageString);
      }

    }*/


 
//process.on("SIGINT", _ => server.close());